package com.example.weatherapp.com.example.weatherapp.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("weather_prefs")
private val LAST_CITY_KEY = stringPreferencesKey("last_city")

class LocalStorage(private val context: Context) {
    val lastCity: Flow<String?> = context.dataStore.data.map { it[LAST_CITY_KEY] }

    suspend fun saveCity(city: String) {
        context.dataStore.edit { it[LAST_CITY_KEY] = city }
    }
}
