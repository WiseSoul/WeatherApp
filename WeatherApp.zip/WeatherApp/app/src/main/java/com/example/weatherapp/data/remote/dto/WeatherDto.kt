package com.example.weatherapp.data.remote.dto

import com.google.gson.annotations.SerializedName

data class WeatherDto(
    val name: String,
    val main: MainDto,
    val weather: List<WeatherInfoDto>
)

data class MainDto(
    val temp: Float,
    @SerializedName("feels_like")
    val feelsLike: Float
)

data class WeatherInfoDto(
    val main: String,
    val description: String,
    val icon: String
)
