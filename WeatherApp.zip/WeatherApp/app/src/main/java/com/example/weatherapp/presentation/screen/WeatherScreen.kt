package com.example.weatherapp.presentation.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.weatherapp.R
import com.example.weatherapp.presentation.viewmodel.UiState
import com.example.weatherapp.presentation.viewmodel.WeatherViewModel

@Composable
fun WeatherScreen(viewModel: WeatherViewModel) {
    val cityInput by viewModel.cityInput.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    var useCelsius by remember { mutableStateOf(true) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // 🔁 City Input with Clear Button
            OutlinedTextField(
                value = cityInput,
                onValueChange = viewModel::onCityInputChange,
                label = { Text(stringResource(R.string.enter_city_name)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                trailingIcon = {
                    if (cityInput.isNotBlank()) {
                        IconButton(onClick = { viewModel.onCityInputChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = stringResource(R.string.clear_input)
                            )
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = viewModel::fetchWeather,
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Search")
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    modifier = Modifier.padding(end = 8.dp),
                    text = "°C"
                )
                Switch(
                    checked = !useCelsius,
                    onCheckedChange = { useCelsius = !it }
                )
                Text(
                    modifier = Modifier.padding(start = 8.dp),
                    text = "°F"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (uiState) {
                is UiState.Idle -> {
                    Text(stringResource(R.string.enter_a_city_min_3_letters_and_tap_search))
                }

                is UiState.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.CenterHorizontally)
                    )
                }

                is UiState.Error -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = (uiState as UiState.Error).message.toString(context),
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }

                is UiState.Success -> {
                    val data = (uiState as UiState.Success).data
                    val displayedTemp =
                        if (useCelsius) data.temperature else data.temperature * 9 / 5 + 32
                    val displayedFeels =
                        if (useCelsius) data.feelsLike else data.feelsLike * 9 / 5 + 32
                    val unit = if (useCelsius) "°C" else "°F"

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth()
                        ) {
                            Text(
                                text = data.city,
                                style = MaterialTheme.typography.headlineSmall
                            )

                            Spacer(Modifier.height(12.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(
                                    painter = rememberAsyncImagePainter(data.iconUrl),
                                    contentDescription = stringResource(
                                        R.string.weather_icon_content_description
                                    ),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(Modifier.width(16.dp))
                                Column {
                                    Text(
                                        stringResource(
                                            R.string.temperature,
                                            "%.1f".format(displayedTemp),
                                            unit
                                        )
                                    )
                                    Text(
                                        stringResource(
                                            R.string.feels_like,
                                            "%.1f".format(displayedFeels),
                                            unit
                                        )
                                    )
                                    Text(stringResource(R.string.condition_data, data.condition))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
