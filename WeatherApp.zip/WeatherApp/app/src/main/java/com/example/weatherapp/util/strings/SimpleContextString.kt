package com.example.weatherapp.util.strings

import android.content.Context
import com.itslearning.core.utils.strings.IContextString

data class SimpleContextString(private val s: String) : IContextString {
    override fun toString(context: Context): String {
        return s
    }
}
