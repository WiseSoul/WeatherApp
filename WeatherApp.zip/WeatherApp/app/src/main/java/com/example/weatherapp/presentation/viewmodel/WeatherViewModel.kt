package com.example.weatherapp.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.R
import com.example.weatherapp.com.example.weatherapp.data.repository.LocalStorage
import com.example.weatherapp.domain.repository.WeatherRepository
import com.example.weatherapp.util.strings.ResourceString
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import retrofit2.HttpException

class WeatherViewModel(
    private val repository: WeatherRepository,
    private val localStorage: LocalStorage
) : ViewModel() {

    private val _cityInput = MutableStateFlow("")
    val cityInput: StateFlow<String> = _cityInput.asStateFlow()

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var fetchJob: Job? = null

    init {
        viewModelScope.launch {
            localStorage.lastCity.collect { saved ->
                saved?.let {
                    _cityInput.value = it
                }
            }
        }
    }

    fun onCityInputChange(newCity: String) {
        _cityInput.value = newCity
    }

    fun fetchWeather() {
        val city = cityInput.value.trim()

        if (city.length < 3) {
            _uiState.value = UiState.Error(ResourceString(R.string.please_enter_at_least_3_letters))
            return
        }

        fetchJob?.cancel() // 👈 Cancel any running fetch
        fetchJob = viewModelScope.launch {
            localStorage.saveCity(city)

            repository.getWeather(city)
                .onStart { _uiState.value = UiState.Loading }
                .catch { e ->
                    val message = when (e) {
                        is HttpException -> {
                            if (e.code() == 404) ResourceString(R.string.city_not_found)
                            else ResourceString(R.string.server_error, e.code())
                        }
                        is java.io.IOException -> ResourceString(R.string.network_error_please_check_your_connection)
                        else -> ResourceString(R.string.unexpected_error, e.message?: "")
                    }
                    _uiState.value = UiState.Error(message)
                }
                .collect { state -> _uiState.value = state }
        }
    }
}
