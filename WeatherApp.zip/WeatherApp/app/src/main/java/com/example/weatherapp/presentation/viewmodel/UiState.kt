package com.example.weatherapp.presentation.viewmodel

import com.example.weatherapp.domain.model.WeatherData
import com.itslearning.core.utils.strings.IContextString

sealed interface UiState {
    object Idle : UiState
    object Loading : UiState
    data class Success(val data: WeatherData) : UiState
    data class Error(val message: IContextString) : UiState
}
