package com.example.weatherapp.util.strings

import android.content.Context
import com.itslearning.core.utils.strings.IContextString

data class ResourceString(private val resId: Int, private val formatArgs: List<Any>) : IContextString {
    constructor(resId: Int, vararg args: Any) : this(resId, args.toList())

    override fun toString(context: Context): String {
        return context.getString(resId, *formatArgs.toTypedArray())
    }
}

