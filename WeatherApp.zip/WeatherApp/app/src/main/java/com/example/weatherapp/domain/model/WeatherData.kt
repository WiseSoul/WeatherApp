package com.example.weatherapp.domain.model

data class WeatherData(
    val city: String,
    val temperature: Float,
    val feelsLike: Float,
    val condition: String,
    val iconUrl: String
)

