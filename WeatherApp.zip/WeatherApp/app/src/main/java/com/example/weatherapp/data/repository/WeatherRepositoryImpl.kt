package com.example.weatherapp.data.repository

import com.example.weatherapp.data.remote.RetrofitInstance
import com.example.weatherapp.domain.model.WeatherData
import com.example.weatherapp.domain.repository.WeatherRepository
import com.example.weatherapp.presentation.viewmodel.UiState
import com.example.weatherapp.util.Constants
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class WeatherRepositoryImpl : WeatherRepository {
    override fun getWeather(city: String): Flow<UiState> = flow {
        val dto = RetrofitInstance.api.getWeatherByCity(city, Constants.API_KEY)
        val weather = dto.weather.firstOrNull()
            ?: throw IllegalStateException("No weather data available")

        val data = WeatherData(
            city = dto.name,
            temperature = dto.main.temp,
            feelsLike = dto.main.feelsLike,
            condition = weather.main,
            iconUrl = "https://openweathermap.org/img/wn/${weather.icon}@2x.png"
        )

        emit(UiState.Success(data))
    }
}


