package com.itslearning.core.utils.strings

import android.content.Context

interface IContextString {
    fun toString(context: Context): String
}
