package com.example.weatherapp.domain.repository

import com.example.weatherapp.presentation.viewmodel.UiState
import kotlinx.coroutines.flow.Flow

interface WeatherRepository {
    fun getWeather(city: String): Flow<UiState>
}
