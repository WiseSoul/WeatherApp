package com.example.weatherapp.di

import com.example.weatherapp.com.example.weatherapp.data.repository.LocalStorage
import com.example.weatherapp.data.repository.WeatherRepositoryImpl
import com.example.weatherapp.domain.repository.WeatherRepository
import com.example.weatherapp.presentation.viewmodel.WeatherViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {
    single<WeatherRepository> { WeatherRepositoryImpl() }
    single { LocalStorage(get()) }
    viewModel { WeatherViewModel(get(), get()) }
}
