package com.example.weatherapp

import com.example.weatherapp.com.example.weatherapp.data.repository.LocalStorage
import com.example.weatherapp.domain.model.WeatherData
import com.example.weatherapp.domain.repository.WeatherRepository
import com.example.weatherapp.presentation.viewmodel.UiState
import com.example.weatherapp.presentation.viewmodel.WeatherViewModel
import com.google.common.truth.Truth.assertThat
import io.mockk.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test

class WeatherViewModelTest {

    private lateinit var repository: WeatherRepository
    private lateinit var localStorage: LocalStorage
    private lateinit var viewModel: WeatherViewModel

    private val mockCity = "Bucharest"
    private val testDispatcher: TestDispatcher = StandardTestDispatcher()

    @OptIn(ExperimentalCoroutinesApi::class)
    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)

        repository = mockk()
        localStorage = mockk(relaxed = true)
        coEvery { localStorage.lastCity } returns flowOf(null)

        viewModel = WeatherViewModel(repository, localStorage)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `onCityInputChange should update cityInput`() = runTest {
        // Arrange
        val input = "Bucharest"

        // Act
        viewModel.onCityInputChange(input)
        val result = viewModel.cityInput.first()

        // Assert
        assertThat(result).isEqualTo(input)
    }

    @Test
    fun `fetchWeather emits Loading then Success when repository returns data`() = runTest {
        // Arrange
        val weatherData = WeatherData(
            city = "Bucharest",
            temperature = 23.0f,
            condition = "Sunny",
            iconUrl = "https://openweathermap.org/img/wn/01d@2x.png",
            feelsLike = 25.0f
        )

        val successFlow = flow {
            kotlinx.coroutines.delay(1) // force suspension so onStart is called
            emit(UiState.Success(weatherData))
        }

        coEvery { repository.getWeather(mockCity) } returns successFlow
        coEvery { localStorage.saveCity(mockCity) } just Runs
        viewModel.onCityInputChange(mockCity)

        val emittedStates = mutableListOf<UiState>()
        val job = launch {
            viewModel.uiState.toList(emittedStates)
        }

        // Act
        viewModel.fetchWeather()
        advanceUntilIdle()
        job.cancel()

        // Assert
        assertThat(emittedStates[0]).isEqualTo(UiState.Idle)
        assertThat(emittedStates[1]).isEqualTo(UiState.Loading)
        assertThat(emittedStates[2]).isEqualTo(UiState.Success(weatherData))

        coVerify { localStorage.saveCity(mockCity) }
    }

    @Test
    fun `fetchWeather emits Loading then Error when repository throws exception`() = runTest {
        // Arrange
        val errorFlow = flow<UiState> {
            kotlinx.coroutines.delay(1) // force suspension so onStart is called
            throw RuntimeException("Network failure")
        }

        coEvery { repository.getWeather(mockCity) } returns errorFlow
        coEvery { localStorage.saveCity(mockCity) } just Runs
        viewModel.onCityInputChange(mockCity)

        val emittedStates = mutableListOf<UiState>()
        val job = launch {
            viewModel.uiState.toList(emittedStates)
        }

        // Act
        viewModel.fetchWeather()
        advanceUntilIdle()
        job.cancel()

        // Assert
        assertThat(emittedStates[0]).isEqualTo(UiState.Idle)
        assertThat(emittedStates[1]).isEqualTo(UiState.Loading)
        assertThat(emittedStates[2]).isInstanceOf(UiState.Error::class.java)

        coVerify { localStorage.saveCity(mockCity) }
    }

    @Test
    fun `fetchWeather emits error when city input is blank or too short`() = runTest {
        // Arrange
        viewModel.onCityInputChange("  ") // blank input

        // Act
        viewModel.fetchWeather()
        val result = viewModel.uiState.first()

        // Assert
        assertThat(result).isInstanceOf(UiState.Error::class.java)
    }
}
